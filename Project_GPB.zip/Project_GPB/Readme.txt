# Locator V1.0

#This program is a calculator to give the number of spaces required to stack skids on the floor.

## Instructions

Select the area where the skids are to be located.
Enter the number of skids that have been received and select the form to stack.
there are three options
single stack. product that is not very stable and requires staying on the floor.
Double stack : 2 skids per skid space
Triple stack: 3 skids per skid space

The results will be displayed below the "Triple stack" button.
##


